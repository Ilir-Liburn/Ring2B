Ring Programming Language Tests
===============================

In this folder we will store the new tests that test the Ring programming language.

Each group of tests will be in a special folder.